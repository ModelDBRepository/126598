
C code for the simulations as described in Tan and Carney (JASA 2005)

//==============================================================
How to compile the files:

(1) In Microsoft Visual C++ (tested in Version 7.0.9466)
   1. Extract all files to a desired directory. This will be used as the
	root directory. The subdirectory "signal" has all the input sounds
	necessary for this simulation. The subdirectory "an3" has the code
	of the auditory-nerve model.
 
   2. Create an empty Win32 console project, named ANnoise, in root directory
   3. Add ANnoise.cpp in the "Source Files" section. This is for the simulation
	of auditory-nerve responses.
   4. Create a sub-directory with name "anresponse" 
      All auditory-nerve simulation outputs will be written in this sub-directory

   5. Create a sub-directory with name "cdresponse" 
      All coincidence-detection simulation outputs will be written in this sub-directory
   6. Create an empty Win32 console project, 
	named CDnoisernt, in root directory
   7. Add cdrnt.cpp in the "Source Files" section. This is for the simulation of 
	coincidence-detection with both rate and timing information.
   8. Create an empty Win32 console project, 
	named CDnoiserate, in root directory
   9. Add cdrate.c in the "Source Files" section. This is for the simulation of 
	coincidence-detection with rate(count) information only.
   10. Create an empty Win32 console project, 
	named cdsingle, in root directory
   11. Add cdsingle.c in the "Source Files" section. This is for the simulation of 
	a small group of coincidence detectors with both rate and timing information.

   
(2) In Borland C++ (tested in version 5.02)
   1. Extract all files to a desired directory. This will be used as the
	root directory. The subdirectory "signal" has all the input sounds
	necessary for this simulation. The subdirectory "an3" has the code
	of the auditory-nerve model.
 
   2. Create an empty Win32 console project in root directory
   
   3. Add a new target in this project with name "annoise"
   4. Make ANnoise.cpp as the only node for the target annoise.exe
	 This is for the simulation of auditory-nerve responses.

   5. Add a new target in this project with name "cdnoisernt"
   6. Make cdnoisernt.cpp as the only node for the target cdnoisernt.exe
	This is for the simulation of 
	coincidence-detection with both rate and timing information.

   7. Add a new target in this project with name "cdnoiserate"
   8. Make cdnoiserate.c as the only node for the target cdnoiserate.exe
	This is for the simulation of 
	coincidence-detection with rate(count) information only.

   9. Add a new target in this project with name "cdsingle"
   10. Make cdsingle.c as the only node for the target cdsingle.exe
 	This is for the simulation of 
	a small group of coincidence detectors with both rate and timing information.

   11. Created a sub-directory with name "anresponse" 
      All auditory-nerve simulation outputs will be written in this sub-directory

   12. Created a sub-directory with name "cdresponse" 
      All coincidence-detection simulation outputs will be written in this sub-directory


//==============================================================
How to run the simulations:
   1. annoise.exe has to be run first before the other executables
      (cdnoisernt.exe; cdnoiserate.exe; and cdsingle.exe) because the
      simulation of coincidence detector responses, by default, use the
      saved AN model responses (unless you want to force the coincidence
      detection simulations to generate new AN responses by themselves, 
      instead of loading previous results from saved files.)

   2. Read the headers of each .cpp or .c files for more information
      if you want to change the settings.

   3. The following files have the simulation results:
	threshold.prediction.noise.bin (auditory-nerve, rate+timing)
	threshold.prediction.noise.rate.txt (auditory-nerve, rate only)
	threshold.prediction.cd.noise.txt (coincidence detector, rate+timing)
	threshold.prediction.cd.noise.rate.txt (coincidence detector, rate only)


Thanks for your interest in our simulations. Any suggestions/comments
will be appreciated!