8/18/03 QT AN3 model for downloading at EarLab website.

How to compile the files:

(1) Uncompress all the files into the same directory 

(2) Open Matlab and go to that directory 

(3) Type the following command in Matlab:
	mex anmod3m.c

How to run it:

(1) Use the following format:

sout=anmod3m(cf, inputsound);

where inputsound has to be a vector and sout is the returned
output with same length as inputsound.

(2) The program supports 50kHz sampling rate only so far.
This means you will have to make your "inputsound" has the
same sampling rate. You can change the sampling rate by changing
the value of tdres in anmod3m.h. However, other sampling rates 
have not been tested and may generate unexpected results.

Thanks for your interest in this model.

Good luck!
	
