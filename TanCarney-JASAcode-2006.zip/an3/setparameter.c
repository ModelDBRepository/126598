/* setparameter.cpp */
/* June 07, 2002    */

int setparameter( float  cf, float *pfp1,
                  double *pta, double *ptb, double *prgain, double *pnlgain,
                  double *pzero_r, int *pdelay)
{
 int error_number=1;

 double rgain80;
 double average_control=0.3357;

 /* parameters before adding middle ear and 10 pair of poles, June 2002 */
 /*
 *pfp1=1.0609*cf-59.2312;
 *pta=     pow(10, log10(cf)*0.9872 + 0.2812);
 *ptb=     pow(10, log10(cf)*1.2913 - 0.6579) - 1000;
 rgain80=  pow(10, log10(cf)*0.6208 + 1.2999);
 *prgain=  pow(10, log10(cf)*0.2948 + 2.1037);
 *pnlgain= (rgain80 - *prgain)/average_control;
 *pzero_r= pow(10, log10(cf)*1.2487 - 0.1890);
 *pdelay= (int)(-26*log(cf)) + 270; */  /*this one is natural log */


 *pfp1=1.0854*cf-106.0034;
 *pta=     pow(10, log10(cf)*1.0230 + 0.1607);
 *ptb=     pow(10, log10(cf)*1.4292 - 1.1550) - 1000;
 rgain80=  pow(10, log10(cf)*0.5732 + 1.5220);
 *prgain=  pow(10, log10(cf)*0.4 + 1.9);   /* 75% */
 //*prgain=  pow(10, log10(cf)*0.3832 + 2.0691);   /* 50% */
 //*prgain=  pow(10, log10(cf)*0.4535 + 1.9214);   /* 25% */

 *pnlgain= (rgain80 - *prgain)/average_control;
 //*pzero_r= pow(10, log10(cf)*1.1038 + 0.1746);       // origional results
 *pzero_r= pow(10, log10(cf)*1.5-0.9 );         // this gives more glide
 *pdelay= 25; /* 0.5ms delay for all CFs */

 return(error_number);
}