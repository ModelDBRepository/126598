// predictionnoise_singlecd_publish.c
// for calc single cd performance
// edited from predictionnoise_cd_publish.cpp

//predictionnoise_cd.c
//this is to evaluate the CD performance based on Eq 5.34 of Mike's thesis

//adapted from predictionnoise.cpp but don't re-calculate AN response, just CD

//the response of CD to each noise/sound_level will not be saved
// only save AN response and averaged CD response
// this will slow .... I was worrying about the disk size required for saving
// all CD responses

// don't have enough memory for expected_a[n_cf+1][n_cf+1][sound_length+1];
// have to save it to disk and load it when needed. Too bad.

// 05/01/2005 copied/edited from predictionnoise_cd.cpp
// 			  Made it available to read from binary files

#define BINARY_IO		1				//If set 1, use binary file format

#define cat_sound_length 12500    //160ms is 1600 pts for kp signal

#define n_noise    20        // total number of noise waveforms
#define n_cf      50

#define use_saved_ANresponse 1 //1-> use saved respones; 0->generate new
#define use_saved_CDresponse 1

#define use_single_cell  1    // 1-> use a very small population of cells
                              // 0-> use all cells available
#define FIBER_I	26
#define FIBER_J 26
// (20, 31) and (26, 26)

#include <math.h>
#include <stdio.h>
#include <stdlib.h>   //added when using random number generator

#include ".\an3\anmod3c.h"
//#include "/BC5/mysource/basic/an3.h"

//=============== copied from anmod3m.c
   /* locations of poles */
 	double ta;   /*Pa in Fig. 3 of the paper */
 	double tb;   /*Pb in Fig. 3 of the paper */
	double rgain;     /* location of the pole closest to img axis */
	double nlgain;                /* gain for the control signal */
   double zero_r;                /* Location of zeros */
   int delayn;                   /* forced delay for AN model */
//================

void generate_cf(float f_lo, float f_hi, int _n_cf, int in_log , float *pointer_f);

void load_hienz_speech(
          int f2,               //formant frequency
          double speech_level,  // 50dB or 70dB
          int noise_number,     // which noise to use, 1-20
          double noise_level);   // SPL of noise

//===========================================================================
//***************************************************************************
//
//     main ()
//
//***************************************************************************
//===========================================================================

int main()
{

 // setup for AN model
 float f_lo;
 float f_hi;
 int total_n;         //total number of fibers in interested frequency range
 int n_each_CF;       // number of fibers for each CF

 float cfs[501];
 float *pointer_cf;

 int delayn;          // don't have to be used
 double ta, tb, rgain, rgain80, nlgain, zero_r, q10;

 // setup for the signal
 int f2;               // frequency of the second formant
 float f2_real;             // in floating point format

 int f2_standard = 17000;

 int f2s[]={19000,   18000,   17500,   17250,   17100,
            17050,   17020,   17010,   17005,   17002,
            17001,   170005,  170002,  170001};
            
 int f2_number;
 int max_f2_number= 13;

 int f2_with_deltaf = 17100;
 double delta_f = 10.0;

 double standard_level;    //50dB or 70dB
 double speech_level;      // 50dB or 70dB  +/- 5dB

 //setup for the noise
 int noise_number;
 int noise_number_max = n_noise;

 double noise_level;
 double sn_ratio;          // signal to noise ratio
 double sn_ratio_included[] = {100, 23, 13, 3};
 int    sn_ratio_n;

 // for the calculation
 double difference;
 static double expected_a[cat_sound_length+1];
 static double expected_b[cat_sound_length+1];
 //static double sout1[sound_length+1];
 // static double sout2[sound_length+1];

 double part1[n_cf+1][n_cf+1];      // part1 value for each fiber
 double part1a;
 double part1_total;        // sum up over all fibers

 double part2a[n_cf+1][n_cf+1];      // value of part2 for each noise
 double part2[n_noise+1];
 double part2_mean;      //mean value of part2 in Eq 5.43
 double part2_var;       // variance of part2
 double threshold;

 // for programming
 float tempread;           // temp variable for reading files
 double temp_double01;
 
 char response_filename[100];
 char threshold_filename[100];
 char inputdir[100];
 char outputdir[100];
 int i;
 int j;
 int n;

 double *sout2;

 FILE *pread01, *psave01;

 // setup for the program
 sprintf(outputdir, ".\\cdresponse\\");
 sprintf(inputdir, ".\\responsetest\\");
 //sprintf(outputdir, ".\\responsezoll\\");
 //sprintf(inputdir, ".\\responsezoll\\");

 // initial setup for sound
 sound_length = cat_sound_length;
 speech_level=50;
 //sn_ratio=13;

 //=============================
 //initial setup for AN model
 //=============================
 //control_type=1;
 pointer_cf=&cfs[1];
 f_lo=1200;
 f_hi=2500;
 total_n = (int)( 30000.0*(log10(f_hi/f_lo)/log10(20000.0/20.0)));
 n_each_CF = (int) (total_n/n_cf);
 //n_each_CF = 1;

 generate_cf(f_lo, f_hi, n_cf, 1 /*log distribution */ , pointer_cf);

 soundin = (double*)calloc(sound_length+1, sizeof(double));
 soundout = (double*)calloc(sound_length+1, sizeof(double));
 meout = (double*)calloc(sound_length+1, sizeof(double));
 control_signal = (double*)calloc(sound_length+1, sizeof(double));
 ihc_out = (double*)calloc(sound_length+1, sizeof(double));
 sout = (double*)calloc(sound_length+1, sizeof(double));

 if (BINARY_IO)
 {
 	sout2 = (double*)calloc(sound_length+1, sizeof(double));
 }

 for (sn_ratio_n=0; sn_ratio_n<4; sn_ratio_n++)
 {

 	sn_ratio = sn_ratio_included[sn_ratio_n];
    printf("sn_ratio = %d\n", (int)sn_ratio);

  // skip calc of AN/CD responses if they are available
  if (use_saved_CDresponse)
  {
  	goto get_part1;
  }

 //=====================================================================
 //calculate the expected average performance with unknown noise and level

response_standard_f: f2= f2_standard;

 //----------------------------------------------
 // response without delta_f
 //----------------------------------------------
 // Loop for noise
 if (use_saved_ANresponse==0)
   {
	 for (noise_number=1; noise_number<= noise_number_max;
 	                                  noise_number=noise_number + 1)
		{
  	    noise_level = speech_level - sn_ratio;
  	    load_hienz_speech(f2, speech_level, noise_number, noise_level);

  	    // response of AN model
  	    for (i=FIBER_I; i<=FIBER_J; i=i+(FIBER_J-FIBER_I))
 	      {
 	       cf=cfs[i];
 	       setparameter( cf, &fp1, &ta, &tb, &rgain, &nlgain, &zero_r, &delayn);
  	       middleear();
     	    controlpath(nlgain);
       	 signalpath(ta, tb, rgain, zero_r);
    	    ihczxd2001();

    	    // save the response
          if (BINARY_IO)
          {
          	sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.bin",
    	           outputdir, f2, noise_number, (int)(sn_ratio), i);
            psave01=fopen(response_filename, "wb");
            fwrite(&(sout[1]), sizeof(double), sound_length, psave01);
            fclose(psave01);
          }
          else
          {
            sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.txt",
    	           outputdir, f2, noise_number, (int)(sn_ratio), i);
   	    	psave01=fopen(response_filename, "w");
  	       	for (n=1; n<=sound_length; n=n+1)
  	         	{
  		         	fprintf(psave01, "%5.18f \n", sout[n]);
	   	      }
   		   fclose(psave01);
          }

         }  //end of for (i=1; i<=n_cf; i=i+1)
 	   }   //end of for (noise_number=1; ...

  } // end of if(use_saved_ANresponse)

 //--------------------------------------
 //averaging for CD without delta_f

 for (i=FIBER_I; i<=FIBER_I; i=i+1)
  {

   for (j=FIBER_J; j<=FIBER_J; j=j+1)
    {

  	  for (n=1; n<=sound_length; n=n+1)
 	   {
 	    expected_a[n] = 0.0;
	   }

  		 for (noise_number=1; noise_number<= noise_number_max;
 		                                  noise_number=noise_number + 1)
 		   {
 		    // load the response for fiber 1
            if (BINARY_IO)
            {
              sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.bin",
 		                inputdir, f2, noise_number, (int)(sn_ratio), i);
              pread01=fopen(response_filename, "rb");
              fread(sout+1, sizeof(double), sound_length, pread01);
              fclose(pread01);
            }
            else
            {
 		        sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.txt",
 		                inputdir, f2, noise_number, (int)(sn_ratio), i);
		        pread01=fopen(response_filename, "r");
 		        for (n=1; n<=sound_length; n=n+1)
  		        {
  		            fscanf(pread01, "%f", &tempread);
                    sout[n]=tempread;
              }
   		     fclose(pread01);
            }

 		    // load the response for fiber 2
            if (BINARY_IO)
            {
              sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.bin",
 		                inputdir, f2, noise_number, (int)(sn_ratio), j);
              pread01=fopen(response_filename, "rb");
              fread(sout2+1, sizeof(double), sound_length, pread01);
              fclose(pread01);

              for (n=1; n<=sound_length; n++)
              {
              	expected_a[n]=expected_a[n] + sout[n]*sout2[n]*tdres;
              }
            }
            else
            {
 		    		sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.txt",
 		                inputdir, f2, noise_number, (int)(sn_ratio), j);
		     		pread01=fopen(response_filename, "r");
 		    		for (n=1; n<=sound_length; n=n+1)
               {
  		       		fscanf(pread01, "%f", &tempread);
             		// add to expected CD response:
             		expected_a[n] = expected_a[n] + tempread*sout[n]*tdres;
               }
	 	  		   fclose(pread01);
            } // end of if(BINARY_IO)

 		   }  // end of for (noise_number=1; ...

		// normalized by number of noises
      for (n=1; n<=sound_length; n=n+1)
 	   {
 	    expected_a[n] = expected_a[n] / noise_number_max;
	   }

 	   // save the averaged response
      if (BINARY_IO)
      {
      	sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
         psave01 = fopen(response_filename, "wb");
         fwrite(&(expected_a[1]), sizeof(double), sound_length, psave01);
         fclose(psave01);
      }
      else
      {
 	   	sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
      	psave01=fopen(response_filename, "w");
	   	for (n=1; n<=sound_length; n=n+1)
 	   	{
 	    	fprintf(psave01, "%5.18f \n", expected_a[n]);
 	   	}
	   	fclose(psave01);
      } // end of if ( BINARY_IO)

    } // end of for (j=i; j<=n_cf; j=j+1)

  } // end of for (i=1; i<=n_cf; i=i+1)

 //----------------------------------------------
 // response with delta_f
 //----------------------------------------------


response_delta_f: f2= f2_with_deltaf;    // use 10Hz as delta_f

 if (use_saved_ANresponse==0)
   {

	 // Loop for noise
 	 for (noise_number=1; noise_number<= noise_number_max;
	                                   noise_number=noise_number + 1)
	 {
 	     noise_level = speech_level - sn_ratio;
 	     load_hienz_speech(f2, speech_level, noise_number, noise_level);

	      // response of AN model
	      for (i=FIBER_I; i<=FIBER_J; i=i+(FIBER_J-FIBER_I))
	        {
	         cf=cfs[i];
            setparameter( cf, &fp1, &ta, &tb, &rgain, &nlgain, &zero_r, &delayn);
 	         middleear();
	         controlpath(nlgain);
	         signalpath(ta, tb, rgain, zero_r);
	         ihczxd2001();

    	    // save the response
          if (BINARY_IO)
          {
          	sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.bin",
    	           outputdir, f2, noise_number, (int)(sn_ratio), i);
            psave01=fopen(response_filename, "wb");
            fwrite(&(sout[1]), sizeof(double), sound_length, psave01);
            fclose(psave01);
          }
          else
          {
            sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.txt",
    	           outputdir, f2, noise_number, (int)(sn_ratio), i);
   	    	psave01=fopen(response_filename, "w");
  	       	for (n=1; n<=sound_length; n=n+1)
  	         	{
  		         	fprintf(psave01, "%5.18f \n", sout[n]);
	   	      }
   		   fclose(psave01);
          }

        }  //end of for (i=1; i<=n_cf; i=i+1)

	 }   //end of for (noise_number=1; ...

 } // end of if (use_saved_ANresponse==0)

 //-----------------------------------------
 //averaging for with delta_f
 f2= f2_with_deltaf;    // use 10Hz as delta_f

 for (i=FIBER_I; i<=FIBER_I; i=i+1)
  {
   for (j=FIBER_J; j<=FIBER_J; j=j+1)
    {

  	  for (n=1; n<=sound_length; n=n+1)
 	   {
 	    expected_b[n] = 0.0;
	   }

  		 for (noise_number=1; noise_number<= noise_number_max;
 		                                  noise_number=noise_number + 1)
 		   {
 		    // load the response for fiber 1
            if (BINARY_IO)
            {
              sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.bin",
 		                inputdir, f2, noise_number, (int)(sn_ratio), i);
              pread01=fopen(response_filename, "rb");
              fread(sout+1, sizeof(double), sound_length, pread01);
              fclose(pread01);
            }
            else
            {
 		        sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.txt",
 		                inputdir, f2, noise_number, (int)(sn_ratio), i);
		        pread01=fopen(response_filename, "r");
 		        for (n=1; n<=sound_length; n=n+1)
  		        {
  		            fscanf(pread01, "%f", &tempread);
                    sout[n]=tempread;
              }
   		     fclose(pread01);
            }

 		    // load the response for fiber 2
            if (BINARY_IO)
            {
              sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.bin",
 		                inputdir, f2, noise_number, (int)(sn_ratio), j);
              pread01=fopen(response_filename, "rb");
              fread(sout2+1, sizeof(double), sound_length, pread01);
              fclose(pread01);

              for (n=1; n<=sound_length; n++)
              {
              	expected_b[n]=expected_b[n] + sout[n]*sout2[n]*tdres;
              }
            }
            else
            {
 		    		sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.b.txt",
 		                inputdir, f2, noise_number, (int)(sn_ratio), j);
		     		pread01=fopen(response_filename, "r");
 		    		for (n=1; n<=sound_length; n=n+1)
               {
  		       		fscanf(pread01, "%f", &tempread);
             		// add to expected CD response:
             		expected_b[n] = expected_b[n] + tempread*sout[n]*tdres;
               }
	 	  		   fclose(pread01);
            } // end of if(BINARY_IO)

 		   }  // end of for (noise_number=1; ...

 	  for (n=1; n<=sound_length; n=n+1)
 	   {
 	    expected_b[n] = expected_b[n] / noise_number_max;
	   }

 	   // save the averaged response
      if (BINARY_IO)
      {
      	sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
         psave01 = fopen(response_filename, "wb");
         fwrite(&(expected_b[1]), sizeof(double), sound_length, psave01);
         fclose(psave01);
      }
      else
      {
 	   	sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
      	psave01=fopen(response_filename, "w");
	   	for (n=1; n<=sound_length; n=n+1)
 	   	{
 	    	fprintf(psave01, "%5.18f \n", expected_b[n]);
 	   	}
	   	fclose(psave01);
      } // end of if ( BINARY_IO)


    } // end of for (j=i; j<=n_cf; j=j+1)

  } // end of for (i=1; i<=n_cf; i=i+1)

 //=====================================================================
 //calculate the delta_prime and threshold

 // Eq.5.34 in Mike's thesis is divided into 2 parts:
 // (part1_total)^2/(part1_total + part2_var)

get_part1: part1_total=0.0;

 for (i=1; i<=n_cf; i=i+1)
  {
   for (j=1; j<=n_cf; j=j+1)
    {
     part1[i][j]=0.0;
    }
  }

 for (i=FIBER_I; i<=FIBER_I; i=i+1)
  {
   for (j=FIBER_J; j<=FIBER_J; j=j+1)
    {
     part1a=0.0;

     // load expected_a and expected_b
      f2=f2_standard;

      if (BINARY_IO)
      {
       sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
       pread01=fopen(response_filename, "rb");
       fread(expected_a+1, sizeof(double), sound_length, pread01);
       fclose(pread01);
      }
      else
      {
       sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
		 pread01=fopen(response_filename, "r");
 		 for (n=1; n<=sound_length; n=n+1)
  		   {
  		    fscanf(pread01, "%f", &tempread);
          expected_a[n]=tempread;
   	   }
   	 fclose(pread01);
      }

      f2= f2_with_deltaf;    // use 10Hz as delta_f
      if (BINARY_IO)
      {
       sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
       pread01=fopen(response_filename, "rb");
       fread(expected_b+1, sizeof(double), sound_length, pread01);
       fclose(pread01);
      }
      else
      {
 	    sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
		 pread01=fopen(response_filename, "r");
 		 for (n=1; n<=sound_length; n=n+1)
  		   {
  		    fscanf(pread01, "%f", &tempread);
          expected_b[n]=tempread;
   	  	}
   	 fclose(pread01);
      }


     for (n=1; n<=sound_length; n=n+1)
      {
        difference=expected_a[n]-expected_b[n];
        part1a = part1a + difference*difference/(expected_a[n]+0.01);
      }
     part1a=part1a/delta_f/delta_f;
     part1a=part1a*tdres;

    part1[i][j]=part1a;

    part1_total = part1_total + part1a;
   }  // end of for (j=i; j<=n_cf; j=j+1)
  }  // end of for (i=1; i<=n_cf; i=i+1)

     // save part1 matrix for future use
 	   sprintf(response_filename, "%spart1.%d.singlecd.txt", outputdir, (int)(sn_ratio));
      psave01=fopen(response_filename, "w");
	   for (i=1; i<=n_cf; i=i+1)
 	   {
       for (j=1; j<=n_cf; j=j+1)
        {
           fprintf(psave01, "%5.18f  ", part1[i][j]);
        }
       fprintf(psave01, "\n");
 	   }
	   fclose(psave01);


 //-----------------------------------------------
 // first get the value for each noise in part2
 part2_mean = 0.0;
 part2_var = 0.0;

 f2=f2_standard;

 for (noise_number=1; noise_number<=noise_number_max;
                                noise_number=noise_number + 1)
   {
     part2[noise_number]=0.0;
     for (i=FIBER_I; i<=FIBER_I; i=i+1)
      {

       //load response for this noise and fiber i
       f2=f2_standard;
       if (BINARY_IO)
       {
        sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.bin",
             inputdir, f2, noise_number, (int)(sn_ratio), i);
        printf("%s\n", response_filename);
        pread01=fopen(response_filename, "rb");
        fread(sout+1, sizeof(double), sound_length, pread01);
        fclose(pread01);
       }
       else
       {
        sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.txt",
             inputdir, f2, noise_number, (int)(sn_ratio), i);
        pread01=fopen(response_filename, "r");
        for (n=1; n<=sound_length; n=n+1)
         {
          fscanf(pread01, "%f", &tempread);
          sout[n]=tempread;
         }
        fclose(pread01);
       } // end of if (BINARY_IO)

       for (j=FIBER_J; j<=FIBER_J; j=j+1)
        {
         part2a[i][j]=0.0;

         //load response for this noise and fiber j
          f2=f2_standard;
       	if (BINARY_IO)
       	{
        	 sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.bin",
             inputdir, f2, noise_number, (int)(sn_ratio), j);
          printf("%s\n", response_filename);
        	 pread01=fopen(response_filename, "rb");
          fread(sout2+1, sizeof(double), sound_length, pread01);
          fclose(pread01);
          for (n=1; n<=sound_length; n++)
          {
          	sout[n] = sout[n]*sout2[n]*tdres;  // CD response
          }
       	}
       	else
       	{
          sprintf(response_filename, "%sresponse.%d.n%d.%ddb.%d.a.txt",
               inputdir, f2, noise_number, (int)(sn_ratio), j);
          pread01=fopen(response_filename, "r");
          for (n=1; n<=sound_length; n=n+1)
            {
             fscanf(pread01, "%f", &tempread);
             sout[n]=sout[n]*tempread*tdres;   // CD response
            }
          fclose(pread01);
         }    // end of if(BINARY_IO)

     // load expected_a and expected_b
       f2=f2_standard;

      if (BINARY_IO)
      {
 	   sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
        printf("%s\n", response_filename);
		pread01=fopen(response_filename, "rb");
      fread(expected_a+1, sizeof(double), sound_length, pread01);
   	fclose(pread01);

      f2= f2_with_deltaf;    // use 10Hz as delta_f
 	   sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.bin",
 	                outputdir, f2, (int)(sn_ratio), i, j);
        printf("%s\n", response_filename);
		pread01=fopen(response_filename, "rb");
      fread(expected_b+1, sizeof(double), sound_length, pread01);
   	fclose(pread01);
      }
      else
      {
 	   sprintf(response_filename, "%saverage.%d.%d.%d.%d.a.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
		pread01=fopen(response_filename, "r");
 		for (n=1; n<=sound_length; n=n+1)
  		   {
  		    fscanf(pread01, "%f", &tempread);
          expected_a[n]=tempread;
   	  }
   	fclose(pread01);

      f2= f2_with_deltaf;    // use 10Hz as delta_f
 	   sprintf(response_filename, "%saverage.%d.%d.%d.%d.b.txt",
 	                outputdir, f2, (int)(sn_ratio), i, j);
		pread01=fopen(response_filename, "r");
 		for (n=1; n<=sound_length; n=n+1)
  		   {
  		    fscanf(pread01, "%f", &tempread);
          expected_b[n]=tempread;
   	  }
   	fclose(pread01);
      }    // end of if (BINARY_IO)
      

         for (n=1; n<=sound_length; n=n+1)
           {
            difference=expected_a[n]-expected_b[n];
            part2a[i][j]=part2a[i][j]+
                            difference/(expected_a[n]+0.01)*sout[n];
           }
          part2a[i][j]=part2a[i][j]/delta_f*tdres;
          part2[noise_number]=part2[noise_number]+part2a[i][j];
        } // end of for (j=i; j<=n_cf; j=j+1)

      } //end of for (i=1; i<=n_cf; i=i+1)

   part2_mean = part2_mean + part2[noise_number];

 }  // end of for (noise_number=1; noise_number<= noise_number_max;
    //                             noise_number= noise_number + 1)

 part2_mean = part2_mean/noise_number_max;

 for (noise_number=1; noise_number<= noise_number_max;
                                     noise_number= noise_number + 1)
  {
   temp_double01=(part2[noise_number] - part2_mean);
   part2_var = part2_var + temp_double01*temp_double01;
  }
 part2_var = part2_var/(noise_number_max-1);

 threshold= sqrt(part1_total + part2_var) / part1_total;
 threshold = threshold/sqrt(total_n*1.0/(n_cf*1.0))*sqrt(n_cf+1.0);


 // save threshold
sprintf(response_filename, "threshold.prediction.singlecd.%d.%d.noise.txt",
 	                FIBER_I, FIBER_J);

 psave01 = fopen(response_filename, "a");
 fprintf(psave01, "%f %f \n", sn_ratio, threshold);
 fclose(psave01);

 } // end of sn_ratio_n loop

 return 1;
}

//===========================================
//*******************************************
//            subroutines
//*******************************************
//===========================================

//=============================================
//   generate_cf ()
//=============================================

 void generate_cf(float f_lo, float f_hi, int _n_cf,
                  int in_log, float *pointer_f)
 {
  int n;
  int i;
  int j;

  float space_factor;
  char filename[100];
  FILE *psave01;

  i=f_lo;
  j=f_hi;

  sprintf(filename, "cf_list.predictionnoise.singlecd.%d.%d.%d.txt",
                                     _n_cf, i, j);

  psave01=fopen(filename, "w");

  if (_n_cf==1) // in case n_cf==1
   {
    *pointer_f=f_lo;
    return;
   }

  space_factor =exp(log(f_hi/f_lo)/(_n_cf - 1));
  for (n=1; n<=_n_cf; n=n+1)
   {
    *pointer_f = f_lo *pow(space_factor, (n-1));
    pointer_f = pointer_f + 1;
    fprintf(psave01, "%f\n", f_lo * pow(space_factor, (n-1)) );
   }
  fclose(psave01);
  return;

 }  // end of generate_cf()

//=============================================
//   load_hienz_speech ()
//=============================================

void load_hienz_speech(
          int f2,               //formant frequency
          double speech_level,  // 50dB or 70dB
          int noise_number,     // which noise to use, 1-20
          double noise_level)   // SPL of noise

{
 extern double *soundin;

 char hienz_speech_file[100];
 int i;
 float temp02;
 double temp01, temp03;
 double noise_input[cat_sound_length];

 char noise_file[100];

 FILE *pread;

  //------------- load speech file -------------
  temp01=0.0;
  sprintf(hienz_speech_file,
          "d:\\speech\\signal\\cat\\newvowel.%d", f2 );

  pread=fopen(hienz_speech_file, "r");
  for (i=1; i<=sound_length; i=i+1)
   {
    if( fscanf(pread, "%f", &temp02)==EOF)
     {
      temp02=0.0;
      break;
     }
    soundin[i]=temp02;
    temp01=temp01 + temp02*temp02;
   }
  fclose(pread);

  // change SPL to be 50dB or 70dB (saved as 0dB from 0Hz-3kHz)
  // put on a 50dB or 70dB scaler
  temp03=pow(10, (speech_level/20.0));
  for (i=1; i<=sound_length; i++)
   {
    soundin[i]=soundin[i]*temp03;
   }

  //---------- load noise file -------------------
  temp01=0.0;
  sprintf(noise_file,
          "d:\\speech\\signal\\cat\\noise.%d", noise_number );

  pread=fopen(noise_file, "r");
  for (i=1; i<=sound_length; i=i+1)
   {
    if( fscanf(pread, "%f", &temp02)==EOF)
     {
      temp02=0.0;
      break;
     }
    noise_input[i]=temp02;
    temp01=temp01 + temp02*temp02;
   }
  fclose(pread);

  // change noise SPL and add to sound signal
  // if the desired SPL (power under 3kHz) of noise is noise_level(dB)
  // then total power of noise within 0--25kHz
  // is 20log10(sqrt(25/3))+noise_level (dB)
  // because the sampling rate of noise is 50kHz
  // then the desired RMS is sqrt(25/3)*[10^(noise_level/20)](2e-5);
  temp03=sqrt(25.0/3.0)*(pow(10.0, noise_level/20.0))
                       *(2.0e-5)/sqrt(temp01/sound_length);
  for (i=1; i<=sound_length; i++)
   {
    soundin[i]=soundin[i] + noise_input[i]*temp03;
   }

} // end of load_hienz_speech


